import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "AMON — Control Nexus",
  description: "The command center for your Discord community.",
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}