import Link from "next/link";
export default function Home() {
  return <main className="shell">
    <header className="top"><Link className="brand" href="/"><span className="sigil">A</span><span>AMON<small>CONTROL NEXUS</small></span></Link><nav><a href="#features">Features</a><a href="#security">Security</a><a className="navbtn" href="/api/auth/discord">Login with Discord</a></nav></header>
    <section className="hero">
      <div className="orb">☾</div><div className="eyebrow">THE MYSTERY BEGINS HERE</div>
      <h1>One dashboard.<br/><em>Complete control.</em></h1>
      <p>Manage your Discord community with powerful moderation, configurable security, support tickets, leveling and automation — all from one place.</p>
      <div className="actions"><a className="primary" href="/api/auth/discord">Continue with Discord ↗</a><a className="secondary" href="#features">Explore features</a></div>
      <div className="hint">Lord of Mysteries inspired • Built for Discord communities</div>
    </section>
    <section id="features" className="section"><div className="eyebrow">THE AMON TOOLKIT</div><h2>Everything your server needs.</h2><div className="cards">
      {[
        ["✧","Welcome & Messages","Join, leave and custom welcome messages."],
        ["⚖","AI Text Moderation","Spam, toxic language, scam-link and flood controls."],
        ["⛨","Anti-Nuke & Anti-Raid","Four configurable protection presets."],
        ["▤","Ticket System","Private support channels, claims and transcripts."],
        ["✦","Leveling System","XP, leaderboards and role rewards."],
        ["⟳","Advanced Automation","Auto roles, responses, schedules and cleanup."],
        ["♫","Voice Activity Logs","Track supported join, leave, mute, camera and stream state events. No voice joining or recording."],
        ["♛","Premium Controls","Subscription plans and owner-managed access."]
      ].map(([icon,title,desc])=><article className="card" key={title}><span>{icon}</span><h3>{title}</h3><p>{desc}</p></article>)}
    </div></section>
    <section id="security" className="security"><div><div className="eyebrow">FOUR PROTECTION PRESETS</div><h2>Choose your level of vigilance.</h2><p>Normal · Medium · Hard · Extremely Strict</p><small>Security actions must be implemented and tested in the connected bot service. No anti-raid system can promise zero bypasses.</small></div><div className="runes">ᚨ　ᛟ　ᚾ</div></section>
    <footer>AMON CONTROL NEXUS <span>© {new Date().getFullYear()} • Secure your community.</span></footer>
  </main>;
}