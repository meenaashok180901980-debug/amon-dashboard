import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
export async function GET(){
 const id=process.env.DISCORD_CLIENT_ID,redirect=process.env.DISCORD_REDIRECT_URI;
 if(!id||!redirect)return NextResponse.json({error:"Discord OAuth environment variables are not configured."},{status:500});
 const state=randomBytes(24).toString("hex");
 const url=new URL("https://discord.com/oauth2/authorize");
 url.searchParams.set("client_id",id);url.searchParams.set("response_type","code");url.searchParams.set("redirect_uri",redirect);
 url.searchParams.set("scope","identify guilds");url.searchParams.set("state",state);
 const res=NextResponse.redirect(url);
 res.cookies.set("amon_oauth_state",state,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:600});
 return res;
}