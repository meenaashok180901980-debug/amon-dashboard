import { NextRequest,NextResponse } from "next/server";
import { createSession } from "@/lib/session";
export async function GET(req:NextRequest){
 const code=req.nextUrl.searchParams.get("code"),state=req.nextUrl.searchParams.get("state");
 const saved=req.cookies.get("amon_oauth_state")?.value;
 if(!code||!state||!saved||state!==saved)return NextResponse.json({error:"Invalid OAuth state. Please try logging in again."},{status:400});
 const body=new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID!,client_secret:process.env.DISCORD_CLIENT_SECRET!,grant_type:"authorization_code",code,redirect_uri:process.env.DISCORD_REDIRECT_URI!});
 const tokenRes=await fetch("https://discord.com/api/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
 if(!tokenRes.ok)return NextResponse.json({error:"Discord token exchange failed. Check OAuth settings."},{status:400});
 const token=await tokenRes.json();
 const userRes=await fetch("https://discord.com/api/users/@me",{headers:{Authorization:`Bearer ${token.access_token}`}});
 if(!userRes.ok)return NextResponse.json({error:"Could not read Discord profile."},{status:400});
 const user=await userRes.json();
 const jwt=await createSession({accessToken:token.access_token,username:user.global_name||user.username,userId:user.id});
 const res=NextResponse.redirect(new URL("/dashboard",req.url));
 res.cookies.set("amon_session",jwt,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:7*24*60*60});
 res.cookies.delete("amon_oauth_state");
 return res;
}