import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
const modules = [
["Welcome & Messages","Configure join, leave and welcome messages."],
["AI Text Moderation","Set text filters, escalation rules and alert channels."],
["Anti-Nuke & Anti-Raid","Choose Normal, Medium, Hard or Extremely Strict."],
["Ticket System","Configure ticket panels, staff roles and transcripts."],
["Leveling System","Set XP, cooldowns, level rewards and leaderboard."],
["Advanced Automation","Configure auto roles, scheduled posts and triggers."],
["Voice Activity Logs","Track supported voice-state changes. AMON never joins voice."],
["Audit Logs","Review moderation, security and configuration events."],
["Premium & Access","Review plans and premium access status."]
];
export default async function Dashboard(){
 const session=await getSession();
 if(!session) redirect("/api/auth/discord");
 return <main className="dash"><header className="top"><a className="brand" href="/"><span className="sigil">A</span><span>AMON<small>CONTROL NEXUS</small></span></a><div className="user">Signed in as <b>{session.username}</b> <a href="/api/auth/logout">Log out</a></div></header>
 <section className="dashhero"><div className="eyebrow">AUTHENTICATED DISCORD SESSION</div><h1>Welcome, {session.username}.</h1><p>Select a module to configure your server. Live configuration becomes available after connecting the AMON bot API.</p></section>
 <section className="serverbox"><h2>Your manageable servers</h2><p>Server listing is fetched securely from Discord using your OAuth session.</p><ServerList/></section>
 <section className="cards dashcards">{modules.map(([name,desc])=><article className="card" key={name}><h3>{name}</h3><p>{desc}</p><span className="soon">Backend connection required</span></article>)}</section>
 <footer>AMON CONTROL NEXUS <span>Discord session protected server-side.</span></footer></main>;
}
async function ServerList(){
 const {getGuilds}=await import("@/lib/discord");
 const session=await getSession();
 if(!session)return null;
 const guilds=await getGuilds(session.accessToken);
 if(!guilds.length)return <p>No manageable servers returned. Make sure you have Manage Server permission and re-authorize Discord.</p>;
 return <div className="guilds">{guilds.map((g:any)=><div className="guild" key={g.id}><b>{g.name}</b><small>{g.owner?"Owner":"Manage Server permission"}</small></div>)}</div>;
}