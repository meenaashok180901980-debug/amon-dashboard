# AMON — Vercel deployment starter

This is a Next.js starter for the AMON Discord dashboard.

## Deploy to Vercel (free subdomain)
1. Create a GitHub account and a new repository named `amon-dashboard`.
2. Extract this ZIP and upload all project files to the repository root.
3. Sign in at https://vercel.com using GitHub.
4. Select **Add New → Project**, import `amon-dashboard`, and deploy.
5. In Vercel → Project → Settings → Environment Variables, add the variables listed below.
6. In Discord Developer Portal → your application → OAuth2, add the exact callback URL:
   `https://YOUR-VERCEL-DOMAIN.vercel.app/api/auth/discord/callback`
7. Add the same URL to `DISCORD_REDIRECT_URI` in Vercel. Redeploy after adding environment variables.

## Required Vercel environment variables
- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `DISCORD_REDIRECT_URI` (your production callback URL)
- `SESSION_SECRET` (long random string, at least 32 characters)

Optional:
- `NEXT_PUBLIC_DISCORD_INVITE_URL`
- `AMON_API_BASE_URL`
- `AMON_API_SECRET`

Do not commit `.env` files or expose bot tokens in frontend code.

## Important scope
- This starter implements a landing page, Discord OAuth2 login, a signed HTTP-only session cookie, and a server-side list of Discord servers where the logged-in user has Manage Server permission.
- Dashboard module cards are a UI shell. They do not yet change live Discord server settings.
- A Discord bot is a separate long-running process and should run on a bot-friendly host (for example, a worker/container host), not as a Vercel serverless function. Connect it to this dashboard through an authenticated API.
- AI moderation provider, anti-nuke enforcement, tickets, XP storage, automation, audit persistence, premium payment verification and `/paid access` token issuance still need implementation.
- Use least-privilege Discord permissions rather than blindly granting Administrator. Test security actions in a private test server.
- Voice state events can report supported join/leave/mute/deafen/camera/stream changes. Discord does not provide a general reliable event that proves a member is recording audio. AMON does not join voice channels or record conversations.
- Never unlock premium based only on a browser form or payment screenshot. Verify payments server-side and issue signed, expiring tokens.
