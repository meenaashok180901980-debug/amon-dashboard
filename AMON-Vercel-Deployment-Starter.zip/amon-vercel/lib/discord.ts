export async function getGuilds(accessToken:string){
 const r=await fetch("https://discord.com/api/users/@me/guilds",{headers:{Authorization:`Bearer ${accessToken}`},cache:"no-store"});
 if(!r.ok)throw new Error("Could not load Discord servers");
 const guilds=await r.json();
 // Discord permission bit 0x20 = MANAGE_GUILD. Do not expose access token to browser.
 return guilds.filter((g:any)=>g.owner || (BigInt(g.permissions)&32n)===32n).map((g:any)=>({id:g.id,name:g.name,owner:g.owner}));
}