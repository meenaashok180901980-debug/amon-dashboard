import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
export type Session={accessToken:string;username:string;userId:string};
const key=()=>{const s=process.env.SESSION_SECRET;if(!s||s.length<32)throw new Error("SESSION_SECRET must be at least 32 characters");return new TextEncoder().encode(s)};
export async function createSession(data:Session){return new SignJWT(data).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(key())}
export async function getSession():Promise<Session|null>{
 const token=cookies().get("amon_session")?.value;if(!token)return null;
 try{const {payload}=await jwtVerify(token,key());return payload as unknown as Session}catch{return null}
}